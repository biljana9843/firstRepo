for x in range(0,36):
    print("HelloWorld")